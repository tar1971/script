#!/bin/sh
#

wget -O /home/stalker.conf https://raw.githubusercontent.com/crazy-FROG1/IPTV/main/stalker.conf && killall -9 enigma2

exit 0




