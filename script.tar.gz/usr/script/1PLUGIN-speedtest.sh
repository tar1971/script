opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/plugins/main/speedtest_1.0_mips32el.ipk
wait
sleep 2;
exit 0




























