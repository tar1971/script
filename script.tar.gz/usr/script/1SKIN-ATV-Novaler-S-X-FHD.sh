#!/bin/sh
# 
##script install skin-Novaler-S-X-FHD##
sleep 1
wget -q https://raw.githubusercontent.com/emil237/skins-openatv/main/skin-Novaler-S-X-FHD.tar.gz -P /tmp
echo "Downloading the Skin Novaler-S-X-FHD ..."
sleep 1
rm -rf /usr/share/enigma2/Novaler-S-X-FHD
echo "old version is removed..."
sleep 1
if [ -f /tmp/skin-Novaler-S-X-FHD.tar.gz ]; then
	tar -xzf /tmp/skin-Novaler-S-X-FHD.tar.gz -C /
fi
sleep 1
rm -rf /tmp/skin-Novaler-S-X-FHD.tar.gz
echo " SKINS Installed..."
sleep 1
echo "e2 restarting..."
sleep 1
killall -9 enigma2
exit 0
