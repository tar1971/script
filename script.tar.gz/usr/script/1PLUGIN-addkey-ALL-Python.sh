wget http://tunisia-dreambox.info/TSplugins/AddKey/installer.sh -O - | /bin/sh





