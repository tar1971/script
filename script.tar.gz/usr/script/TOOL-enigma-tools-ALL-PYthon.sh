wget https://raw.githubusercontent.com/emil237/enigma-tools-update/main/installer.sh -qO - | /bin/sh    






