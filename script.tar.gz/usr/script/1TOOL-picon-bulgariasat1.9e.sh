wget https://raw.githubusercontent.com/emil237/picon-bulgariasat/main/installer.sh -qO - | /bin/sh


