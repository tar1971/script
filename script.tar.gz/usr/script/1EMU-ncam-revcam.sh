wget https://raw.githubusercontent.com/emil237/ncam-revcam/main/installer.sh -O - | /bin/sh






