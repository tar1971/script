#!/bin/sh

#
version=5.8r2
#############################################################
TEMPATH=/tmp
PLUGINPATH=/usr/lib/enigma2/python/Plugins/Extensions/epanel

# remove old version
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/epanel

echo ""
# Download and install plugin
cd /tmp
set -e
echo "===> Downloading And Installing epanel plugin Please Wait ......"
echo
wget "https://raw.githubusercontent.com/emil237/plugins/main/epanel_py3.tar.gz"
tar -xzf epanel_py3.tar.gz -C /
set +e
rm -f epanel_py3.tar.gz

echo ""
sync
echo "##############################################################"
echo "#         epanel $version INSTALLED SUCCESSFULLY             #"
echo "##############################################################"
echo "**************************************************************"
echo "##############################################################"
echo "#              your Device will RESTART Now                  #"
echo "##############################################################"
sleep 3
exit 0
