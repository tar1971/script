wget https://raw.githubusercontent.com/emil237/picon-nilesat/main/installer.sh -qO - | /bin/sh


