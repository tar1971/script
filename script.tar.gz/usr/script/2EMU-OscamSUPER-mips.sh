#!/bin/sh
echo "Install Oscam-supcam_ MIPS!!!"
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/oscam_Supcam_r798_all.ipk" > /tmp/oscam_Supcam_r798_all.ipk
sleep 1
echo "installing Oscam-Supcam...."
cd /tmp
opkg install /tmp/oscam_Supcam_r798_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/oscam_Supcam_r798_all.ipk
sleep 2
killall -9 enigma2
exit
