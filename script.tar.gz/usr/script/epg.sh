#!/bin/sh

echo 1 > /proc/sys/vm/drop_caches
echo 2 > /proc/sys/vm/drop_caches
echo 3 > /proc/sys/vm/drop_caches


python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beinConnect.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/elcin.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/bein.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/satTvB.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/osnplay.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beinent.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/jawwyOS.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beincin.py

exit 0



