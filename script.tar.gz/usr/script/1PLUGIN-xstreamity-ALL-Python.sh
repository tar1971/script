wget https://raw.githubusercontent.com/emil237/xtreamity/main/installer.sh -O - | /bin/sh



