
#!/bin/sh
#

wget -O /tmp/skin-batman-fhd_v1.0_all.ipk
https://raw.githubusercontent.com/emil237/skins-openatv/main/skin-batman-fhd_v1.0_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/skin-batman-fhd_v1.0_all.ipk
wait
sleep 2;
exit 0















