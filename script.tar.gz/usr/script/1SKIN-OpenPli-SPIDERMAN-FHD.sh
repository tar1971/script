#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-SPIDERMAN-FHD-By-Muaath.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-SPIDERMAN-FHD-By-Muaath.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /tmp/*.ipk
sleep 2;
exit 0














