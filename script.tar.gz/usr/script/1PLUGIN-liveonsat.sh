#!/bin/sh
#

wget -O /var/volatile/tmp/liveonsat_1.0_arm.ipk "https://raw.githubusercontent.com/emil237/plugins/main/liveonsat_1.0_arm.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/liveonsat_1.0_arm.ipk
wait
sleep 2;
exit 0

































