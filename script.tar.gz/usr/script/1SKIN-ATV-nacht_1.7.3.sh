#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/skins-openatv/main/skin-nacht-atv.tar.gz"
wait
tar -xzf skin-nacht-atv.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skin-nacht-atv.tar.gz
wait
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
















