#!/bin/sh
echo "Install Oscam "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/oscam_all.deb" > /tmp/oscam_all.deb
sleep 1
echo "install Oscam...."
cd /tmp
dpkg -i /tmp/oscam_all.deb
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/oscam_all.deb
sleep 2
killall -9 enigma2
exit
