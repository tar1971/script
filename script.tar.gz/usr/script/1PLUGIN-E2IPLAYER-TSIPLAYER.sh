wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/E2IPLAYER+TSIPLAYER/installer.sh -O - | /bin/sh

