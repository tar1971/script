#!/bin/sh
sleep 1
echo "Install EPG-PRO-grabber"
echo ""
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/EPG-PRO-grabber.tar.gz" > /tmp/EPG-PRO-grabber.tar.gz
sleep 1
echo "installing ...."
cd /tmp
tar -xzf EPG-PRO-grabber.tar.gz  -C /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
cd 
rm /tmp/EPG-PRO-grabber.tar.gz
echo "OK"
killall -9 enigma2
exit






