
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-MetropolisHD-by.Franc.MoD_OpenPLi6.2_all.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-MetropolisHD-by.Franc.MoD_OpenPLi6.2_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-MetropolisHD-by.Franc.MoD_OpenPLi6.2_all.ipk
wait
sleep 2;
exit 0










