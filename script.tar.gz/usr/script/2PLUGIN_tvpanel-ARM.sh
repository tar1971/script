#!/bin/sh
echo "install plugin TV panel"
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/tvaddon-panel_all.ipk" > /tmp/tvaddon-panel_all.ipk
sleep 1
echo "install plugin...."
cd /tmp
opkg install /tmp/tvaddon-panel_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/tvaddon-panel_all.ipk
sleep 2
killall -9 enigma2
exit
